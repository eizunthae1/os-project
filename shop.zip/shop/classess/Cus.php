
<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Formate.php');

?>

<?php

class Cus 
{
	

private $db;
private $fm;

	public function __construct()
	{
		
		$this->db = new Database();
		$this->fm = new Format();
	}




	public function getAllCustomer()
	{
	$query = "SELECT * FROM tbl_customer ORDER BY id DESC";
	$result = $this->db->select($query);
	return $result;
	}

 public function getCustomerById($id){
$query = "SELECT * FROM tbl_customer WHERE id='$id'";
	$result = $this->db->select($query);
	return $result;

 }

 

 public function delCustomerById($id){
 	$query = "DELETE FROM tbl_customer WHERE id = '$id'";
	$deldata = $this->db->delete($query);
	if ($deldata) {
		$msg = "<span class='success'>Customer Deleted Successfully.</span>";
				return $msg;
	}else{
$msg = "<span class='error'>Customer Not Deleted !</span>";
				return $msg;

	}
     }



	 
	}
?>