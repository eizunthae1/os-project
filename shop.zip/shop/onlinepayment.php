<?php include 'inc/header.php';?>
<html>
<head><link rel="stylesheet" href="pay.css"></head><body><form action="successful.php" method="post">
<div class="wrappe">
  <div class="checkout_wrapper">
    <div class="product_info">
      <img src="photo/loogo.jpg" alt="product">
      <div class="cont">
        <h3>Mon Traditional</h3>
        <p>Website</p>
      </div>
    </div>
    <div class="checkout_form">
      <p>Payment Section</p>
      <div class="details">
        <div class="section">
          <input type="text" placeholder="Name" required name="name" >
        </div>
        <div class="section">
          <input type="text" placeholder="Address" name="address"required>
        </div>
        <div class="section">
          <input type="text" placeholder="Phone Number" name="phone" required>
        </div>
        
        
        
       
        <div class="btn">
        <input type="submit" value="PAY">
        
        </div><br>
         <a href="orderdetails.php" class="ba">Back</a>
      </div>
    </div>
  </div>
</div></form></body>
</html>
<?php include 'inc/footer.php';?>