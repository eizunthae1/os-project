<?php include 'inc/header.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Style sheet -->
    <link rel="stylesheet" href="css/styl.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;1,700;1,900&display=swap" rel="stylesheet">

    <!-- FOnt Awesome -->
    <script src="https://kit.fontawesome.com/e48d166edc.js" crossorigin="anonymous"></script>

    <title>Our Team page</title>

</head>
<body>
    <div class="container">
        <div class="section-title">
            <h1>About Us&nbsp;&nbsp;&nbsp;</h1>
        </div>

        <div class="row">


            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="img/a2.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Ei Zun Thae</h2>
                        <h3>Leader</h3>
                        <p>She is a student in Computer University of Thaton.She is very active</p>
                        <h4>eizunthae77@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="#" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-yt"> <i class="fab fa-youtube"></i></a>
                        <br><br>
                        
                    </div>
                    
                </div>
            </div>

            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="img/b1.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Khine Zin</h2>
                        <h3>Group Member</h3>
                        <p>She is a student in Computer University of Thaton.She is very active</p>
                        <h4>khinezinucstt016@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="#" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-yt"> <i class="fab fa-youtube"></i></a>
                    </div>
                    
                </div>
            </div>

            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="img/c1.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2> Khine Zin Lay</h2>
                        <h3>Group Member</h3>
                        <p>She is a student in Computer University of Thaton.She is very active</p>
                        <h4>khinezinlayucstt060@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="#" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-yt"> <i class="fab fa-youtube"></i></a>
                    </div>
                    
                </div>
            </div>

            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="img/p1.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Paing Thet Kyaw</h2>
                        <h3>Group Member</h3>
                        <p>He is a student in Computer University of Thaton.He is very active</p>
                        <h4>paingthetkyaw957@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="#" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-yt"> <i class="fab fa-youtube"></i></a>
                    </div>
            
                 </div>
            </div>

            

        </div>

    </div>

    
</body>
</html>
<?php include 'inc/footer.php';?>