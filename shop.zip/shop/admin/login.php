<?php include '../classess/Adminlogin.php';?>
<?php
$al = new Adminlogin();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$adminUser = $_POST['adminUser'];
	$adminPassword = $_POST['adminPassword'];

	$loginchk = $al->adminlogin($adminUser,$adminPassword);
}
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/login.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<form action="login.php" method="post">
			<h1>Admin Login</h1>
<span style="color: red;font-size: 18px;">
	<?php
if (isset($loginchk)) {
	echo $loginchk;
}

	?>

</span>

			<div>
				<input type="text" placeholder="Username"  name="adminUser"/>
			</div>
			<div>
				<input type="password" placeholder="Password"  name="adminPassword"pattern='(?=.*\d){8,}' 
             title='Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters' required/>
			</div>
			<div class="login">
				
				<input type="submit" value="Log in" />
			
			</div>
		</form><!-- form -->
		<div class="button">
			<marquee>
			<a href="#">Mon Traditional Accessories Ordering System                 </a></marquee>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>