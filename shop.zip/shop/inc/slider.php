	<div class="header_bottom">
		<div class="header_bottom_left">
			<div class="section group">
                <?php 
                $getoneset = $pd->latestFromOneset();

                if ($getoneset) {
                    while ($result = $getoneset->fetch_assoc()) {
                
                 ?>
                <div class="listview_1_of_2 images_1_of_2">
                    <div class="listimg listimg_2_of_1">
                         <a href="details.php?proid=<?php echo $result['productId']; ?>"> <img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
                    </div>
                    <div class="text list_2_of_1">
                        <h2>Oneset</h2>
                        <p><?php echo $result['productName']; ?></p>
                        <div class="button"><span><a href="details.php?proid=<?php echo $result['productId']; ?>">Add to cart</a></span></div>
                   </div>
               </div>

               <?php }} ?>    

               <?php 
                $getlongyi= $pd->latestFromLongyi();

                if ($getlongyi) {
                    while ($result = $getlongyi->fetch_assoc()) {
                
                 ?>        
                <div class="listview_1_of_2 images_1_of_2">
                    <div class="listimg listimg_2_of_1">
                         <a href="details.php?proid=<?php echo $result['productId']; ?>"> <img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
                    </div>
                    <div class="text list_2_of_1">
                        <h2>Longyi</h2>
                        <p><?php echo $result['productName']; ?></p>
                        <div class="button"><span><a href="details.php?proid=<?php echo $result['productId']; ?>">Add to cart</a></span></div>
                   </div>
               </div>

                 <?php }} ?>    
            </div>
            <div class="section group">

                  <?php 
                $getBag = $pd->latestFromBag();

                if ($getBag) {
                    while ($result = $getBag->fetch_assoc()) {
                
                 ?>
                <div class="listview_1_of_2 images_1_of_2">
                    <div class="listimg listimg_2_of_1">
                         <a href="details.php?proid=<?php echo $result['productId']; ?>"> <img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
                    </div>
                    <div class="text list_2_of_1">
                        <h2>Bag</h2>
                        <p><?php echo $result['productName']; ?></p>
                        <div class="button"><span><a href="details.php?proid=<?php echo $result['productId']; ?>">Add to cart</a></span></div>
                   </div>
               </div>

               <?php }} ?>

                 <?php 
                $getTshirt = $pd->latestFromTshirt();

                if ($getTshirt) {
                    while ($result = $getTshirt->fetch_assoc()) {
                
                 ?>            
                
                <div class="listview_1_of_2 images_1_of_2">
                    <div class="listimg listimg_2_of_1">
                         <a href="details.php?proid=<?php echo $result['productId']; ?>"> <img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
                    </div>
                    <div class="text list_2_of_1">
                        <h2>Tshirt</h2>
                        <p><?php echo $result['productName']; ?></p>
                        <div class="button"><span><a href="details.php?proid=<?php echo $result['productId']; ?>">Add to cart</a></span></div>
                   </div>
               </div>
                <?php }} ?>
            </div>
            <div class="section group">

                  <?php 
                $getThikePone = $pd->latestFromThikePone();

                if ($getThikePone) {
                    while ($result = $getThikePone->fetch_assoc()) {
                
                 ?>
                <div class="listview_1_of_2 images_1_of_2">
                    <div class="listimg listimg_2_of_1">
                         <a href="details.php?proid=<?php echo $result['productId']; ?>"> <img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
                    </div>
                    <div class="text list_2_of_1">
                        <h2>Thikepone</h2>
                        <p><?php echo $result['productName']; ?></p>
                        <div class="button"><span><a href="details.php?proid=<?php echo $result['productId']; ?>">Add to cart</a></span></div>
                   </div>
               </div>

               <?php }} ?>

                 <?php 
                $getCoupleSet = $pd->latestFromCoupleSet();

                if ($getCoupleSet) {
                    while ($result = $getCoupleSet->fetch_assoc()) {
                
                 ?>            
                
                <div class="listview_1_of_2 images_1_of_2">
                    <div class="listimg listimg_2_of_1">
                         <a href="details.php?proid=<?php echo $result['productId']; ?>"> <img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
                    </div>
                    <div class="text list_2_of_1">
                        <h2>CoupleSet</h2>
                        <p><?php echo $result['productName']; ?></p>
                        <div class="button"><span><a href="details.php?proid=<?php echo $result['productId']; ?>">Add to cart</a></span></div>
                   </div>
               </div>
                <?php }} ?>
            </div>

			 <div class="clear"></div>
        </div>
             <div class="header_bottom_right_images">
           <!-- FlexSlider -->
             
            <section class="slider">
                  <div class="flexslider">
                    <ul class="slides">
                        <li><img src="photo/o5.jpg" alt=""/></li>
                        <li><img src="images/bag.jpg" alt=""/></li>
                        <li><img src="photo/c7.jpg" alt=""/></li>
                        <li><img src="images/mt4.jpg" alt=""/></li>
                    </ul>
                  </div>
          </section>
<!-- FlexSlider -->
        </div>
      <div class="clear"></div>
  </div>